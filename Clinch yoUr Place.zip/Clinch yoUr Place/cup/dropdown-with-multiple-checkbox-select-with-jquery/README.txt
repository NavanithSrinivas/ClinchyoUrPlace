A Pen created at CodePen.io. You can find this one at http://codepen.io/elmahdim/pen/hlmri.

 Dropdown with Multiple checkbox select with jQuery.